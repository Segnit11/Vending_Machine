/*
 * This page only vends the candies
 */
package assignment.pkg2.pkg2.vendingmachine;

import static assignment.pkg2.pkg2.vendingmachine.MAIN_VENDING_MACHINE.TryParseDouble;
import static assignment.pkg2.pkg2.vendingmachine.MAIN_VENDING_MACHINE.TryParseInt;
import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

/**
 *
 * @author stulujr.local
 */
public class Candy_Vending_Machine implements IVendingMachine <Candy> {
  
   //---------------------------------------------------------------------------------------------------- 
   //PROPERTIES
   //---------------------------------------------------------------------------------------------------- 
    
protected Queue<Candy> SlotA = new LinkedList();

      public Queue<Candy> getSlotA(){

        return this.SlotA;
    }

    public void setSlotA(Queue<Candy> val){

         this.SlotA = val;    
    }
        
protected Queue<Candy> SlotB = new LinkedList();
   
    
    public Queue<Candy> getSlotB(){

        return this.SlotB;
    }

    public void setSlotB(Queue<Candy> val){

         this.SlotB = val;    
    }
        
protected Queue<Candy> SlotC = new LinkedList();
    
  
    public Queue<Candy> getSlotC(){

        return this.SlotC;
    }

    public void setSlotC(Queue<Candy> val){

        this.SlotC = val;    
    }
 
  /*
   * Below I created a getters and setters for Money and Quantity for each Soda.
   */  
    
 Double Money;
    
 
    protected Double getMoney(){
           
        return Money;
    }
    
    public void setMoney(double val){
        
        this.Money = val;
    }
     
 protected int Quantity; 
  
    protected int getQuantity(){
    
        return Quantity; 
    }
    protected void setQuantity(int val){
    
        this.Quantity = val;
    }
   
    NumberFormat formatter = NumberFormat.getCurrencyInstance();  //Helps us to get a currency form infront of the amount of the item on the print page
    
   //---------------------------------------------------------------------------------------------------- 
   //CONSTRUCTOR
   //---------------------------------------------------------------------------------------------------- 
    
       // Full Constructor of the Vending Machine with alot of properities inside it 

    public Candy_Vending_Machine(double Money, Queue<Candy> mySlotA, Queue<Candy> mySlotB, Queue<Candy> mySlotC ) throws CloneNotSupportedException{
       
            SlotA = mySlotA;
            SlotB = mySlotB;
            SlotC = mySlotC;
     
            
        Candy sk1 = new Candy("Skittles", 4.20);    // Creating a Skittles instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                SlotA.add(sk1.clone());
                
            }
    
        Candy sn1 = new Candy("Snickers", 1.42);    // Creating a Snickers instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
                
                SlotB.add(sn1.clone());
                
            }
            
        Candy mm1 = new Candy("MandMs",42.42);      // Creating a MandMs instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
                
                SlotC.add(mm1.clone());
                
            }
            
            setMoney(Money); //Money in the machine
    }
    
   //---------------------------------------------------------------------------------------------------- 
   //METHODS
   //---------------------------------------------------------------------------------------------------- 
    
    @Override
    public String GetMachineInfo() {     
        
        DisplayContents();
     
      return null;
    }

    
    
    @Override
    public String DisplayContents() {
        
        System.out.println("");
        System.out.println("+-------------------------------------------------------------+");       
        System.out.println("|     You Chose a Candy Machine. Here Are Your Options:       |");   
        System.out.println("+-------------------------------------------------------------+");
        
        if(!SlotA.isEmpty()){
            System.out.println("|     A: " + SlotA.peek().getName() + "  ("+  SlotA.size() + ") " + "= " + SlotA.peek().getPrice() + "                                 |");
            
        }
 
        if(!SlotB.isEmpty()){
            System.out.println("|     B: " + SlotB.peek().getName() + "  ("+  SlotB.size() + ") " + "= " + SlotB.peek().getPrice() + "                                |");
        }
        
        if(!SlotC.isEmpty()){
            System.out.println("|     C: " + SlotC.peek().getName() + "  ("+  SlotC.size() + ") " + "= " + SlotC.peek().getPrice() + "                                 |");
            System.out.println("|                                                             |");
        }

      return null;
    }


    
    public Candy VendItem(String slotCode) {          //.....Below there will be a bunch of if statements and also for loops which will help us to Vend the items(Candy)
        
        //SlotA
        if (slotCode.equals("A") && SlotA.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + SlotA.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                SlotA.poll();
            }
        }
        
        else if(SlotA.equals("A") && Quantity > SlotA.size()){
        
            System.out.println("The Vending Machine has only " + SlotA.size() + "Skittles. Please Make an Order below the amount left " + SlotA.size()+ ".");
        }
        
        //SlotB
        if (slotCode.equals("B") && SlotB.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + SlotB.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                SlotB.poll();
            }
        }
        else if(SlotB.equals("B") && Quantity > SlotB.size()){
        
            System.out.println("The Vending Machine has only " + SlotB.size() + "Snickers. Please Make an Order below the amount left " + SlotB.size()+ ".");
        }
        
        //SlotC
        if (slotCode.equals("C") && SlotC.size()>0){
            
             System.out.println("\n");
             System.out.println("Here is your " + SlotC.peek().getName());
             System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                SlotC.poll();
            }
        }
        else if(SlotC.equals("C") && Quantity > SlotC.size()){
        
            System.out.println("The Vending Machine has only " + SlotC.size() + "Snickers. Please Make an Order below the amount left " + SlotC.size()+ ".");
        }

      return null;         
    }

    
  
    private static void VendingCandy(Double Price, int Quantity, Candy_Vending_Machine CandyMachine, NumberFormat formatter, String slotCode) {
    
        // Below the scanner will ask for the How many Candies does the user wants interms of Number
        
     Scanner input = new Scanner(System.in);
        
        System.out.println("HOW MUCH DO YOU NEED IN NUMBERS: ");
        String sth = input.nextLine().trim();
        
        int neededQuantity = TryParseInt(sth);
    
    while(neededQuantity == 0)
        {
            // This promot will appear if the user didn't insert the write type of answer for the question HOW MUCH YOU NEED:
            System.out.println("ERROR!");
            System.out.println("INVALID INPUT. Please try again.");
            System.out.println("");
            System.out.println("INSERT AN ACTUAL NUMBER: "); 
            
            sth = input.nextLine().trim();
                               
            neededQuantity = TryParseInt(sth);    //.....This is used to store and parse.....I got help on this from Elias
        }
    
    String ss = "";
        
    while (neededQuantity > Quantity || Quantity < 0 || neededQuantity<0 ) 
            {
              // This promot will appear if the user inserts alot of quantity more than their is inside the vending machine for the question HOW MUCH YOU NEED:
                System.out.println("TOO MUCH PRODUCT ASKED. PRODUCTS OUT OF STOCK " + "\n"+" THE MACHINE HAS ONLY "+ Quantity +" INSIDE IT. ");
                System.out.println("Try again.");
                System.out.println("PLEASE INSERT THE AMOUNT YOU WANT TO PURCHASE: "); 
                ss = input.nextLine().toUpperCase().trim();
                
        if(ss.equals("Q")){
            break;
            }
                neededQuantity = (int)TryParseInt(ss);               
        }
    /*
    * I got help from Elias around here how to do the total amount or the total cost
    */
        if (!ss.equals("Q")){
        
            CandyMachine.setQuantity(neededQuantity);      // ....used to set the wanted quantity

            Double Total_Cost = neededQuantity * Price;   //.....used to display the total cost
            System.out.println("\n"+" TOTAL COST "+ formatter.format(Total_Cost));
            System.out.println("\n"+"INSERT PAYMENT FOR THE ITEM: ");
            String aaa= input.nextLine().trim();
            Double PaymentAmount = TryParseDouble(aaa);
            CandyMachine.TakeMoney(PaymentAmount);
        
        while(PaymentAmount < Total_Cost){
            
            System.out.println("\n"+"PAYMENT INSUFFICIENT! Please insert at least an additional "+ formatter.format(Total_Cost-PaymentAmount)+" OR CLICK 'Q' TO QUIT.");
            String Pay = input.nextLine().trim();
            
            if(Pay.toUpperCase().equals("Q")){ 
                
                CandyMachine.ReturnMoney(PaymentAmount);System.exit(0);
            }
            else{
                
                Double PayMore = TryParseDouble(Pay);
                PaymentAmount += PayMore;
                CandyMachine.addMoney(PayMore);
            }
        }
            CandyMachine.VendItem(slotCode);
            double change = PaymentAmount - Total_Cost;
            
            if(change>0){
                
                CandyMachine.GiveChange(change);
//Final Note for the user

        System.out.println("++================================================================++");
        System.out.println("||//////////////////THANKS FOR THE PURCHASE!!!////////////////////||");     
        System.out.println("||////////////////////HAVE A GOOD DAY:)///////////////////////////||");
        System.out.println("++================================================================++");
        System.out.println("  THE MACHINE HAS "+formatter.format(CandyMachine.getMoney())+" STORED.  ");
        System.out.println("++================================================================++");
   
        }
      }
    }
    

public static void VendOrder(String slotCode, double Price, int Quantity,Candy_Vending_Machine VendCandy, NumberFormat formatter) throws CloneNotSupportedException{ 
       
    switch (slotCode){
        case "A":
            if (VendCandy.SlotA.isEmpty()){
                System.out.println("The Skittles you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendCandy.SlotA.peek().getPrice();
                        Quantity = VendCandy.SlotA.size();
                        VendingCandy(Price, Quantity, VendCandy,formatter,slotCode);
                    }
                    break;
        case "B":
            if (VendCandy.SlotB.isEmpty()){
                System.out.println("The Snickers you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendCandy.SlotB.peek().getPrice();
                        Quantity = VendCandy.SlotB.size();
                        VendingCandy(Price, Quantity, VendCandy,formatter,slotCode);
                    }
                    break;
        case "C":
            if (VendCandy.SlotC.isEmpty()){
                     System.out.println("The M&M's you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendCandy.SlotC.peek().getPrice();
                        Quantity = VendCandy.SlotC.size();
                        VendingCandy(Price, Quantity, VendCandy,formatter,slotCode);
                    }
                    break;
                case "Q": 
                     System.out.println("");
                     break;
                // Unless and Otherwise, Go back to the Main Menu  
                default:
                    System.out.println(" THE CHOICE YOU MADE IS NOT VALID.");
                    break;
        }                  
    }
    
    @Override
    public void TakeMoney(double amount) {        // .....This is an inside process the moment the payment is done, the payment that have been done will go and added to the total store amount(200.00).
    
        AddMoney(amount);
        System.out.println("\n");
        System.out.println("THANK YOU FOR THE PAYMENT YOU MADE");
        System.out.println("----------------------------------");
     }

    @Override
    public void ReturnMoney(double amount){
        
        AddMoney(-amount);
        System.out.println("Here Is Your Money" + amount);
    }
       
    public void GiveChange(double amount){         //....In this method we calculate the change for the user, if the user pay more money.
        
        AddMoney(-amount);     
        System.out.println("\n"+"Here is your change: "+formatter.format(amount) +" ." );       
    }    
        
    public String ItemCounter(Queue <Candy> item){       //....I got a help on this Part From a Tutor and I understand that it helps to track the amount of the Candy
        
        if(item.size()<=0){
            System.out.println("WE ARE OUT OF THE ITEM FOR NOW.");
        }
        else{
            System.out.println(item.peek().getName() + " " + item.size() + " - " + item.peek().getName());
        }
        
      return null;
    }

    public void AddMoney(double d) {
        this.Money += d;
        
         }

    void addMoney(double d) {
        this.Money +=d;
    }   
}
