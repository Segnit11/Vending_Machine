/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2.pkg2.vendingmachine;

import static assignment.pkg2.pkg2.vendingmachine.MAIN_VENDING_MACHINE.TryParseDouble;
import static assignment.pkg2.pkg2.vendingmachine.MAIN_VENDING_MACHINE.TryParseInt;
import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

/**
 *
 * @author stulujr.local
 */

public class StarWars_Vending_Machine implements IVendingMachine<StarWarsCharacter> {

//    private static int TryParseInt(String sth) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
//
//    private static Double TryParseDouble(String aaa) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }

    
protected Queue<StarWarsCharacter> Asajj = new LinkedList();

    public Queue<StarWarsCharacter> getAsajj(){

        return this.Asajj;
    }

    public void setAsajj(Queue<StarWarsCharacter> val){

         this.Asajj = val;    
    }
        
    
protected Queue<StarWarsCharacter> Bariss = new LinkedList();

    public Queue<StarWarsCharacter> getBariss(){

        return this.Bariss;
    }

    public void setBariss(Queue<StarWarsCharacter> val){

         this.Bariss = val;    
    }
  
protected Queue<StarWarsCharacter> Darth = new LinkedList();

    public Queue<StarWarsCharacter> getDarth(){

        return this.Darth;
    }

    public void setDarth(Queue<StarWarsCharacter> val){

         this.Darth = val;    
    }
    
protected Queue<StarWarsCharacter> Emperor = new LinkedList();

    public Queue<StarWarsCharacter> getEmperor(){

        return this.Emperor;
    }

    public void setEmperor(Queue<StarWarsCharacter> val){

         this.Emperor = val;    
    }

protected Queue<StarWarsCharacter> Kylo = new LinkedList();

    public Queue<StarWarsCharacter> getKylo(){

        return this.Kylo;
    }

    public void setKylo(Queue<StarWarsCharacter> val){

         this.Kylo = val;    
    }   
    
    
protected Queue<StarWarsCharacter> Luke = new LinkedList();

    public Queue<StarWarsCharacter> getLuke(){

        return this.Luke;
    }

    public void setLuke(Queue<StarWarsCharacter> val){

         this.Luke = val;    
    }     
    
protected Queue<StarWarsCharacter> Obi = new LinkedList();

    public Queue<StarWarsCharacter> getObi(){

        return this.Obi;
    }

    public void setObi(Queue<StarWarsCharacter> val){

         this.Obi = val;    
    }  
    
    
protected Queue<StarWarsCharacter> Princess = new LinkedList();

    public Queue<StarWarsCharacter> getPrincess(){

        return this.Princess;
    }

    public void setPrincess(Queue<StarWarsCharacter> val){

         this.Princess = val;    
    }  
    
protected Queue<StarWarsCharacter> Rey = new LinkedList();

    public Queue<StarWarsCharacter> getRey(){

        return this.Rey;
    }

    public void setRey(Queue<StarWarsCharacter> val){

         this.Rey = val;    
    }  
    
protected Queue<StarWarsCharacter> Storm = new LinkedList();

    public Queue<StarWarsCharacter> getStorm(){

        return this.Storm;
    }

    public void setStorm(Queue<StarWarsCharacter> val){

         this.Storm = val;    
    }      
    
    
protected Queue<StarWarsCharacter> Yoda = new LinkedList();

    public Queue<StarWarsCharacter> getYoda(){

        return this.Yoda;
    }

    public void setYoda(Queue<StarWarsCharacter> val){

         this.Yoda = val;    
    }      
 
  /*
   * Below I created a getters and setters for Money and Quantity for each StarWarsChararcter.
   */  
    
 Double Money;
    
    protected Double getMoney(){
           
        return Money;
    }
    
    public void setMoney(double val){
        
        this.Money = val;
    }
     
 protected int Quantity; 
  
    protected int getQuantity(){
    
        return Quantity; 
    }
    protected void setQuantity(int val){
    
        this.Quantity = val;
    }
    
    NumberFormat formatter = NumberFormat.getCurrencyInstance();  //Helps us to get a currency form infront of the amount of the item on the print page
    
    
   //---------------------------------------------------------------------------------------------------- 
   //CONSTRUCTOR
   //---------------------------------------------------------------------------------------------------- 
     
    
        // Full Constructor of the Vending Machine with alot of properities inside it 

    public StarWars_Vending_Machine(double Money, Queue<StarWarsCharacter> myAsajj, Queue<StarWarsCharacter> myBariss, Queue<StarWarsCharacter> myDarth, Queue<StarWarsCharacter> myEmperor, Queue<StarWarsCharacter> myKylo, Queue<StarWarsCharacter> myLuke, Queue<StarWarsCharacter> myObi, Queue<StarWarsCharacter> myPrincess, Queue<StarWarsCharacter> myRey, Queue<StarWarsCharacter> myStorm, Queue<StarWarsCharacter> myYoda) throws CloneNotSupportedException{
       
            Asajj= myAsajj;
            Bariss=myBariss;
            Darth=myDarth;
            Emperor=myEmperor;
            Kylo=myKylo;
            Luke=myLuke;
            Obi=myObi;
            Princess=myPrincess;
            Rey=myRey;
            Storm=myStorm;
            Yoda=myYoda;
    
        StarWarsCharacter Ch1 = new StarWarsCharacter("Asajj","Ventess", new TheForce(88,"Dark"),4.56);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Asajj.add(Ch1.clone());    
            }
    
        StarWarsCharacter Ch2 = new StarWarsCharacter("Bariss","Offee", new TheForce(85,"Light"),5.67);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Bariss.add(Ch2.clone());    
            }
            
        StarWarsCharacter Ch3 = new StarWarsCharacter("Darth","Vader", new TheForce(100,"Dark"),7.96);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Darth.add(Ch3.clone());    
            }
            
        StarWarsCharacter Ch4 = new StarWarsCharacter("Emperor","Palpatine", new TheForce(97,"Dark"), 5.76);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){ 
                Emperor.add(Ch4.clone());    
            }
            
        StarWarsCharacter Ch5 = new StarWarsCharacter("Kylo","Ren", new TheForce(95,"Dark"), 9.34);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Kylo.add(Ch5.clone());    
            }
            
        StarWarsCharacter Ch6 = new StarWarsCharacter("Luke","Skywalker", new TheForce(97,"Light"),3.88);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){  
                Luke.add(Ch6.clone());    
            }

        StarWarsCharacter Ch7 = new StarWarsCharacter("Obi Wan","Kenobi", new TheForce(85,"Light"),4.31);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Obi.add(Ch7.clone());   
            }

        StarWarsCharacter Ch8 = new StarWarsCharacter("Princess","Leia", new TheForce(75,"Light"),6.23);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Princess.add(Ch8.clone());    
            }

        StarWarsCharacter Ch9 = new StarWarsCharacter("Rey","", new TheForce(96,"Light"),5.34);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Rey.add(Ch9.clone());    
            }

        StarWarsCharacter Ch10 = new StarWarsCharacter("Storm","Trooper",new TheForce(1,"Dark"),1.87);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Storm.add(Ch10.clone());   
            }

        StarWarsCharacter Ch11 = new StarWarsCharacter("Yoda","",new TheForce(99,"Light"), 2.65);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Yoda.add(Ch11.clone());    
            }
    
        setMoney(Money); //Money in the machine
    }

   //---------------------------------------------------------------------------------------------------- 
   //METHODS
   //---------------------------------------------------------------------------------------------------- 
    
    @Override
    public String GetMachineInfo() {     
        
        DisplayContents();
     
      return null;
    }

    @Override
    public String DisplayContents() {
        
        System.out.println("");
        System.out.println("+-----------------------------------------------------------+");
        System.out.println("|    You Chose a StarWars Machine. Here Are Your Options:   |");
        System.out.println("+-----------------------------------------------------------+");
        
        if(!Asajj.isEmpty()){
            System.out.println("|    A:" + Asajj.peek().getFirstName() + " " + Asajj.peek().getLastName() + "------("+  Asajj.size() + ") " + "= " + Asajj.peek().getPrice() + "                       |");    
        }
 
        if(!Bariss.isEmpty()){
            System.out.println("|    B:" + Bariss.peek().getFirstName() + " " + Bariss.peek().getLastName() + "-------("+  Bariss.size() + ") " + "= " + Bariss.peek().getPrice() + "                       |");    
        }
        
        if(!Darth.isEmpty()){
            System.out.println("|    C:" + Darth.peek().getFirstName() + " " + Darth.peek().getLastName() + "--------("+  Darth.size() + ") " + "= " + Darth.peek().getPrice() + "                       |");    
        }
        
        if(!Emperor.isEmpty()){
            System.out.println("|    D:" + Emperor.peek().getFirstName() + " " + Emperor.peek().getLastName() + "--("+  Emperor.size() + ") " + "= " + Emperor.peek().getPrice() + "                       |");    
        }
 
        if(!Kylo.isEmpty()){
            System.out.println("|    E:" + Kylo.peek().getFirstName() + " " + Kylo.peek().getLastName() + "-----------("+  Kylo.size() + ") " + "= " + Kylo.peek().getPrice() + "                       |");    
        }
        
        if(!Luke.isEmpty()){
            System.out.println("|    F:" + Luke.peek().getFirstName() + " " + Luke.peek().getLastName() + "-----("+  Luke.size() + ") " + "= " + Luke.peek().getPrice() + "                       |");   
        }
        
        if(!Obi.isEmpty()){
            System.out.println("|    G:" + Obi.peek().getFirstName() + " " + Obi.peek().getLastName() + "-----("+  Obi.size() + ") " + "= " + Obi.peek().getPrice() + "                       |");    
        }
        
        if(!Princess.isEmpty()){
            System.out.println("|    H:" + Princess.peek().getFirstName() + " " + Princess.peek().getLastName() + "------("+  Princess.size() + ") " + "= " + Princess.peek().getPrice() + "                       |");    
        }
        
        if(!Rey.isEmpty()){
            System.out.println("|    I:" + Rey.peek().getFirstName() + " " + Rey.peek().getLastName() + "---------------("+  Rey.size() + ") " + "= " + Rey.peek().getPrice() + "                       |");    
        }
        
        if(!Storm.isEmpty()){
            System.out.println("|    J:" + Storm.peek().getFirstName() + " " + Storm.peek().getLastName() + "------("+  Storm.size() + ") " + "= " + Storm.peek().getPrice() + "                       |");   
        }
        
        if(!Yoda.isEmpty()){
            System.out.println("|    K:" + Yoda.peek().getFirstName() + " " + Yoda.peek().getLastName() + "--------------("+  Yoda.size() + ") " + "= " + Yoda.peek().getPrice() + "                       |");    
            System.out.println("|                                                           |");
        }

      return null;
    }
 
    
    public StarWarsCharacter VendItem(String slotCode) {          //.....Below there will be a bunch of if statements and also for loops which will help us to Vend the items(Candy)
        
        //Asajj
        if (slotCode.equals("A") && Asajj.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Asajj.peek().getFirstName() + Asajj.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){   
                Asajj.poll();
            }
        }
        else if(Asajj.equals("A") && Quantity > Asajj.size()){
            System.out.println("The Vending Machine has only " + Asajj.size() + "Asajj. Please Make an Order below the amount left " + Asajj.size()+ ".");
        }
        
        //Bariss
        if (slotCode.equals("B") && Bariss.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Bariss.peek().getFirstName() + Bariss.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){   
                Bariss.poll();
            }
        }
        else if(Bariss.equals("B") && Quantity > Bariss.size()){
            System.out.println("The Vending Machine has only " + Bariss.size() + "Bariss. Please Make an Order below the amount left " + Darth.size()+ ".");
        }
        
        //Darth
        if (slotCode.equals("C") && Darth.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Darth.peek().getFirstName() + Darth.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){   
                Darth.poll();
            }
        }
        else if(Darth.equals("C") && Quantity > Darth.size()){
            System.out.println("The Vending Machine has only " + Darth.size() + "Darth. Please Make an Order below the amount left " + Darth.size()+ ".");
        }

        //Emperor
        if (slotCode.equals("D") && Emperor.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Emperor.peek().getFirstName() + Emperor.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){     
                Emperor.poll();
            }
        }
        else if(Emperor.equals("D") && Quantity > Emperor.size()){
            System.out.println("The Vending Machine has only " + Emperor.size() + "Emperor. Please Make an Order below the amount left " + Emperor.size()+ ".");
        }
        
        //Kylo
        if (slotCode.equals("E") && Kylo.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Kylo.peek().getFirstName() + Kylo.peek().getLastName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){           
                Kylo.poll();
            }
        }
        else if(Kylo.equals("F") && Quantity > Kylo.size()){
            System.out.println("The Vending Machine has only " + Kylo.size() + "Kylo. Please Make an Order below the amount left " + Kylo.size()+ ".");
        }
        
        //Luke
        if (slotCode.equals("G") && Luke.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Luke.peek().getFirstName() + Luke.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){    
                Luke.poll();
            }
        }
        else if(Luke.equals("G") && Quantity > Luke.size()){
            System.out.println("The Vending Machine has only " + Luke.size() + "Luke. Please Make an Order below the amount left " + Luke.size()+ ".");
        }
         
        //Obi
        if (slotCode.equals("H") && Obi.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Obi.peek().getFirstName() + Obi.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){   
                Obi.poll();
            }
        }
        else if(Obi.equals("H") && Quantity > Obi.size()){
            System.out.println("The Vending Machine has only " + Obi.size() + "Obi. Please Make an Order below the amount left " + Obi.size()+ ".");
        }
        
        //Rey
        if (slotCode.equals("I") && Rey.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Rey.peek().getFirstName() + Rey.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){    
                Rey.poll();
            }
        }
        else if(Rey.equals("I") && Quantity > Rey.size()){
            System.out.println("The Vending Machine has only " + Rey.size() + "Rey. Please Make an Order below the amount left " + Rey.size()+ ".");
        }
        
         //Storm
        if (slotCode.equals("J") && Storm.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Storm.peek().getFirstName() + Storm.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){    
                Storm.poll();
            }
        }
        else if(Storm.equals("J") && Quantity > Storm.size()){     
            System.out.println("The Vending Machine has only " + Storm.size() + "Storm. Please Make an Order below the amount left " + Storm.size()+ ".");
        }
        
         //Yoda
        if (slotCode.equals("K") && Yoda.size()>0){    
            System.out.println("\n");
            System.out.println("Here is your " + Yoda.peek().getFirstName() + Yoda.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){     
                Yoda.poll();
            }
        }
        else if(Yoda.equals("K") && Quantity > Yoda.size()){
            System.out.println("The Vending Machine has only " + Yoda.size() + "Yoda. Please Make an Order below the amount left " + Yoda.size()+ ".");
        }
        
      return null;         
    }

    
private static void VendingStarWars(double Price, int Quantity, StarWars_Vending_Machine StarWarsMachine, NumberFormat formatter, String slotCode) {
    
        // Below the scanner will ask for the How many StarWar Characters does the user wants interms of Number
        
     Scanner input = new Scanner(System.in);
        
        System.out.println("HOW MUCH DO YOU NEED IN NUMBERS: ");
        String sth = input.nextLine().trim();
        
        int neededQuantity = TryParseInt(sth);
    
    while(neededQuantity == 0)
        {
            // This promot will appear if the user didn't insert the write type of answer for the question HOW MUCH YOU NEED: 
            System.out.println("ERROR!");
            System.out.println("INVALID INPUT. Please try again.");
            System.out.println("");
            System.out.println("INSERT AN ACTUAL NUMBER: ");
            
            sth = input.nextLine().trim();
                               
            neededQuantity = TryParseInt(sth);    //.....This is used to store and parse.....I got help on this from Elias
        }
    String ss = "";
        
    while (neededQuantity > Quantity || Quantity < 0 || neededQuantity<0 ) 
            {
              // This promot will appear if the user inserts alot of quantity more than their is inside the vending machine for the question HOW MUCH YOU NEED:
                System.out.println("TOO MUCH PRODUCT ASKED. PRODUCTS OUT OF STOCK " + "\n"+" THE MACHINE HAS ONLY "+ Quantity +" INSIDE IT. ");
                System.out.println("Try again.");
                System.out.println("\n");
                System.out.println("PLEASE INSERT THE AMOUNT YOU WANT TO PURCHASE: "); 
                ss = input.nextLine().toUpperCase().trim();
                
        if(ss.equals("Q")){
            break;
            }
                neededQuantity = (int)TryParseInt(ss);               
        }
    /*
    * I got help from Elias around here how to do the total amount or the total cost  
    */
         if (!ss.equals("Q")){
        
            StarWarsMachine.setQuantity(neededQuantity);      // ....used to set the wanted quantity

            Double Total_Cost = neededQuantity * Price;   //.....used to display the total cost
            System.out.println("\n"+" TOTAL COST "+ formatter.format(Total_Cost));
            System.out.println("\n"+"INSERT PAYMENT FOR THE ITEM: ");
            String aaa= input.nextLine().trim();
            Double PaymentAmount = TryParseDouble(aaa);
            StarWarsMachine.TakeMoney(PaymentAmount);
        
        while(PaymentAmount < Total_Cost){
            
            System.out.println("\n"+"PAYMENT INSUFFICIENT! Please insert at least an additional  "+ formatter.format(Total_Cost-PaymentAmount)+" or click 'Q' to quit.");
            String Pay = input.nextLine().trim();
            
            if(Pay.toUpperCase().equals("Q")){ 
                
                StarWarsMachine.ReturnMoney(PaymentAmount);System.exit(0);
            }
            else{
                
                Double PayMore = TryParseDouble(Pay);
                PaymentAmount += PayMore;
                StarWarsMachine.addMoney(PayMore);
            }
        }
            StarWarsMachine.VendItem(slotCode);
            double change = PaymentAmount - Total_Cost;
            
            if(change>0){
            
                StarWarsMachine.GiveChange(change);
//Final Note for the user

        System.out.println("++================================================================++");
        System.out.println("||//////////////////THANKS FOR THE PURCHASE!!!////////////////////||");     
        System.out.println("||////////////////////HAVE A GOOD DAY:)///////////////////////////||");
        System.out.println("++================================================================++");
        System.out.println("  THE MACHINE HAS "+formatter.format(StarWarsMachine.getMoney())+" STORED.  ");
        System.out.println("++================================================================++");
        
       }
     }
   }    


public void VendOrder(String slotCode, double Price, int Quantity, StarWars_Vending_Machine VendStarWarsCharacter, NumberFormat formatter)
    {
        //This switch case accounts for all of the options and their respectives outcomes
        switch (slotCode)
        {
                case "A":
                    if (VendStarWarsCharacter.Asajj.isEmpty()){
                        System.out.println("The Character Asajj is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Asajj.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Asajj.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "B":
                    if (VendStarWarsCharacter.Bariss.isEmpty()){
                        System.out.println("The Character Bariss is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Bariss.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Bariss.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "C":
                    if (VendStarWarsCharacter.Darth.isEmpty()){
                        System.out.println("The Character Darth is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Darth.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Darth.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "D":
                    if (VendStarWarsCharacter.Emperor.isEmpty()){
                        System.out.println("The Character Emperor is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Emperor.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Emperor.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "E":
                    if (VendStarWarsCharacter.Kylo.isEmpty()){
                        System.out.println("The Character Kylo is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Kylo.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Kylo.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "F":
                    if (VendStarWarsCharacter.Luke.isEmpty()){
                        System.out.println("The Character Luke is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Luke.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Luke.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "G":
                    if (VendStarWarsCharacter.Obi.isEmpty()){
                        System.out.println("The Character Obi is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Obi.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Obi.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "H":
                    if (VendStarWarsCharacter.Princess.isEmpty()){
                        System.out.println("The Character Princess is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Princess.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Princess.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "I":
                    if (VendStarWarsCharacter.Rey.isEmpty()){
                        System.out.println("The Character Rey is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Rey.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Rey.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "J":
                    if (VendStarWarsCharacter.Storm.isEmpty()){
                        System.out.println("The Character Storm is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Storm.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Storm.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "K":
                    if (VendStarWarsCharacter.Yoda.isEmpty()){
                        System.out.println("The Character Yoda is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendStarWarsCharacter.Bariss.peek().getPrice();
                        Quantity = VendStarWarsCharacter.Bariss.size();
                        VendingStarWars(Price, Quantity, VendStarWarsCharacter, formatter, slotCode);
        
                    }
                    break;
                case "Q": 
                     System.out.println("");

                     break;
                // Otherwise, get back to displaying the menu  
                default:
                    System.out.println("THE CHOICE YOU MADE IS NOT VALID.");
                    break;
        }               
    }
   
    @Override
    public void TakeMoney(double amount) {          // .....This is an inside process the moment the payment is done, the payment that have been done will go and added to the total store amount(200.00).
    
        AddMoney(amount);
        System.out.println("\n");
        System.out.println("THANK YOU FOR THE PAYMENT YOU MADE");
        System.out.println("----------------------------------");
     }

    @Override
    public void ReturnMoney(double amount){
        
        AddMoney(-amount);
        System.out.println("Here Is Your Money" + amount);
    }
       
    public void GiveChange(double amount){         //....In this method we calculate the change for the user, if the user pay more money.
        
        AddMoney(-amount);     
        System.out.println("\n"+"Here is your change: "+formatter.format(amount) +" ." );       
    }    
        
    public String ItemCounter(Queue <StarWarsCharacter> item){       //....I got a help on this Part From a Tutor and I understand that it helps to track the amount of the Candy
        
        if(item.size()<=0){
            
            System.out.println("WE ARE OUT OF THE ITEM FOR NOW.");
        }
        
        else{
            
            System.out.println(item.peek().getFirstName() + item.peek().getLastName() + " " + item.size() + " - " + item.peek().getFirstName() + item.peek().getLastName());
        }
        
      return null;
    }

    public void AddMoney(double d) {
        this.Money += d;
        
         }

    void addMoney(double d) {
        this.Money +=d;
    }
}
