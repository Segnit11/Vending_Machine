/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2.pkg2.vendingmachine;

import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.Scanner;

/**
 *
 * @author stulujr.local
 */
public class MAIN_VENDING_MACHINE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws CloneNotSupportedException {
        
                NumberFormat formatter = NumberFormat.getCurrencyInstance();
                Candy_Vending_Machine CandyMachine = new Candy_Vending_Machine(200.00, new LinkedList<Candy>(), new LinkedList<Candy>(), new LinkedList<Candy>());   
                Soda_Vending_Machine SodaMachine = new Soda_Vending_Machine(400.00, new LinkedList<Soda>(), new LinkedList<Soda>(), new LinkedList<Soda>(), new LinkedList<Soda>(), new LinkedList<Soda>(), new LinkedList<Soda>());   
                StarWars_Vending_Machine StarWarsMachine = new StarWars_Vending_Machine(600.00, new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>());   
                All_Vending_Machine AllMachine = new All_Vending_Machine(800.00, new LinkedList<Candy>(), new LinkedList<Candy>(), new LinkedList<Candy>(), new LinkedList<Soda>(), new LinkedList<Soda>(), new LinkedList<Soda>(), new LinkedList<Soda>(), new LinkedList<Soda>(), new LinkedList<Soda>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>(), new LinkedList<StarWarsCharacter>());   
                
    // Setting up Variables 
    Double Price = 0.0;
    int Quantity = 0;
    boolean loop = true; 
    String userChoice = "";
   
Scanner in = new Scanner(System.in);
        while(!userChoice.equals("Q")){
            
            //Content to be Displayed
            System.out.println("-------------------------------------------------");
            System.out.println("MAIN MENU");
            System.out.println("-------------------------------------------------");
            System.out.println("Choose The Vending Machine You Want To Use?");
            System.out.println("A. Candy Vending Machine.");
            System.out.println("B. Soda Vending Machine.");
            System.out.println("C. StarWars Vending Machine.");
            System.out.println("D. All In All");
            System.out.println("Q. Quit");
            
            
            //Collecting user's input
            userChoice = in.nextLine().toUpperCase().trim();

            // Perform user-defined action
            switch (userChoice) {
                case "A":
                    
                    
                    String slotCode="";
                    
                    //Continues to happen as long as none of the option including Q is not chosen.
                    while (!slotCode.equals("Q")){
                        
                        // Displaying the contents of the machine
                        CandyMachine.DisplayContents();
                        System.out.println("|    Q: Go back to the initial screen.                        |");
                        System.out.println("+-------------------------------------------------------------+");       
                        slotCode=in.nextLine().trim().toUpperCase();
                        //Processing the Order
                        CandyMachine.VendOrder(slotCode, Price, Quantity, CandyMachine, formatter);
                    }
                    break;
                case "B":

                    slotCode="";
                    
                    //Continues to happen as long as none of the option including Q is not chosen.
                    while (!slotCode.equals("Q")){
                        
                        // Displaying the contents of the machine
                        SodaMachine.DisplayContents();
                        System.out.println("|    Q: Go back to the initial screen.                                    |");
                        System.out.println("+-------------------------------------------------------------------------+");
                        slotCode=in.nextLine().trim().toUpperCase();
                        
                        //Processing the Order
                        
                        SodaMachine.VendOrder(slotCode, Price, Quantity, SodaMachine, formatter);
                    }                    
                    break;
                case "C":
                    
                    slotCode="";
                    
                    //Continues to happen as long as none of the option including Q is not chosen.
                    while (!slotCode.equals("Q")){
                        
                        // Displaying the contents of the machine
                        StarWarsMachine.DisplayContents();
                        System.out.println("|    Q: Go back to the initial screen.                      |");
                        System.out.println("+-----------------------------------------------------------+");
                        slotCode=in.nextLine().trim().toUpperCase();
                        
                        //Processing the Order
                        
                        StarWarsMachine.VendOrder(slotCode, Price, Quantity, StarWarsMachine, formatter);
                    }
                    
                    break;
            
                  case "D":
                    
                    slotCode="";
                    
                    //Continues to happen as long as none of the option including Q is not chosen.
                    while (!slotCode.equals("Q")){
                        
                        // Displaying the contents of the machine
                        AllMachine.DisplayContents();
                        System.out.println("|    Q: Go back to the initial screen.                                    |");
                        System.out.println("+-------------------------------------------------------------------------+");
                        slotCode=in.nextLine().trim().toUpperCase();
                        
                        //Processing the Order
                        
                        StarWarsMachine.VendOrder(slotCode, Price, Quantity, StarWarsMachine, formatter);
                    }
                    
                    break;  
 
                case "Q":
                    System.out.println("Thank you for stopping by");
                    System.exit(0);
                default:
                    System.out.println("");
                    break;
            } 
        }
    }
    
       //The below two methods I got help from Eliyas.
   
    public static Double TryParseDouble(String A){
        
        try{
            return Double.parseDouble(A);
        }
        catch(NumberFormatException DN){return 0.00;}
        
    }
    
    public static int TryParseInt(String A){
        
        try{
            return Integer.parseInt(A);
        }
        catch(NumberFormatException DN){return 0;}
        
    }
  

    private static int tryParsingInt(String val) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static Double tryParsingDouble(String reChoice2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static void AllVendingProcesser(double Price, int Quantity, All_Vending_Machine VendAll, NumberFormat formatter, String slotCode) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
