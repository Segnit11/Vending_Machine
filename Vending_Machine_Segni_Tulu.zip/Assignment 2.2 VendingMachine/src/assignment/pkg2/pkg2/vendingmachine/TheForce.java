/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2.pkg2.vendingmachine;

/**
 *
 * @author stulujr.local
 */
public class TheForce implements Cloneable{
 
    //--------------------------------------------------------------------------
    //PROPERTIES
    //--------------------------------------------------------------------------
    
   public int Strength = 0;    // Creating getters and setters for the Strength property which the characters will have a Strength between 1-100

    public int getStrength() {
        
        return Strength;   
    }

    public void setStrength(int Strength) {
        
        this.Strength = Strength;   
    }


    public String Side;    // Creating getters and setters for the Side property which will be between light and dark 
    
         public String getSide() {
       
             return Side;
    }
        
    public void setSide(String Side) {
       
        this.Side = Side;
    }
    
    //--------------------------------------------------------------------------
    //CONSTRUCTORS
    //--------------------------------------------------------------------------
    
    public TheForce(int aStrength, String aSide){               // Calling the object properties which are the strength and the side 
    
           setStrength(aStrength); 
           setSide(aSide); 
    }
    
    
   /*
   *This is a clone method used to clone the Force property of the StarWarsCharacter
   */


    @Override
    
    public StarWarsCharacter clone() throws CloneNotSupportedException {
        return (StarWarsCharacter) super.clone();
    }
        
}

