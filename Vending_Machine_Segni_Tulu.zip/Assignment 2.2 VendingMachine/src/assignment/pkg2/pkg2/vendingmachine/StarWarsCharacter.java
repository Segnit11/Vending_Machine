/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2.pkg2.vendingmachine;

/**
 *
 * @author stulujr.local
 */
public class StarWarsCharacter implements Cloneable{
    
    
    //--------------------------------------------------------------------
    //Properties
    //--------------------------------------------------------------------
    
    
    private String FirstName; 
        
        public String getFirstName(){
        
            return this.FirstName;
        }
    
        public void setFirstName(String val){
            
             this.FirstName = val;    
        }
        
       
    private String LastName; 
    
        public String getLastName(){
            
            return this.LastName;  
        }

        public void setLastName(String val){
        
            this.LastName = val;
        }
        
    
    private double Price;            
        
        public double getPrice(){
            
            return this.Price;
        }
    
        public void setPrice(double val){
        
            this.Price = val;
        }
        
        
    public TheForce Force; 
    
        public TheForce getForce(){
        
            return this.Force;
        }
        
        public void setForce(TheForce val){
        
            this.Force = val;
        }
        
        

    //---------------------------------------------------------------------
    //Constructor 
    //---------------------------------------------------------------------
    // Calling the object properties inulding no argument, first and last name, first last and force name, and at thte last which has all the above object properties 
        
    
    public StarWarsCharacter(){
      }

     public StarWarsCharacter(String aFirstName, String aLastName,TheForce aForce, double aPrice){
         
          FirstName = aFirstName;
          LastName = aLastName;
          Force = aForce;
          Price = aPrice;
      }
        

  /*
   *This is a clone method used to clone the StarWarsCharacter
   */
 
     @Override
     
    public StarWarsCharacter clone() throws CloneNotSupportedException {                    
        
        return (StarWarsCharacter) super.clone();
    }
       

   
  }    

