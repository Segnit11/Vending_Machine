 /*
 * This Vending Machine only vends Soda
 */
package assignment.pkg2.pkg2.vendingmachine;

import static assignment.pkg2.pkg2.vendingmachine.MAIN_VENDING_MACHINE.TryParseDouble;
import static assignment.pkg2.pkg2.vendingmachine.MAIN_VENDING_MACHINE.TryParseInt;
import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

/**
 *
 * @author stulujr.local
 */
public class Soda_Vending_Machine implements IVendingMachine<Soda> {

   //---------------------------------------------------------------------------------------------------- 
   //PROPERTIES
   //---------------------------------------------------------------------------------------------------- 

protected Queue<Soda> Pepsi = new LinkedList();

    public Queue<Soda> getPepsi(){

        return this.Pepsi;
    }

    public void setPepsi(Queue<Soda> val){

         this.Pepsi = val;    
    }
        
    
protected Queue<Soda> PepsiZeroSugar = new LinkedList();
   
    
    public Queue<Soda> getPepsiZeroSugar(){

        return this.PepsiZeroSugar;
    }

    public void setPepsiZeroSugar(Queue<Soda> val){

         this.Pepsi = val;  
    
    }
    
protected Queue<Soda> CocaCola = new LinkedList();
    
  
    public Queue<Soda> getCocaCola(){

        return this.CocaCola;
    }

    public void setCocaCola(Queue<Soda> val){

         this.CocaCola = val;   
    }
    
protected Queue<Soda> DietCoke = new LinkedList();
    
  
    public Queue<Soda> getDietCoke(){

        return this.DietCoke;
    }

    public void setDietCoke(Queue<Soda> val){

         this.DietCoke = val;   
    } 
 
protected Queue<Soda> FantaOrange = new LinkedList();
    
  
    public Queue<Soda> getFantaOrange(){

        return this.FantaOrange;
    }

    public void setFantaOrange(Queue<Soda> val){

         this.FantaOrange = val;   
    } 


protected Queue<Soda> FantaPineapple = new LinkedList();
    
  
    public Queue<Soda> getFantaPineapple(){

        return this.FantaPineapple;
    }

    public void setFantaPineapple(Queue<Soda> val){

         this.FantaPineapple = val;   
    }     
    
  /*
   * Below I created a getters and setters for Money and Quantity for each Candy.
   */  
    
 Double Money;
    
 
    protected Double getMoney(){
           
        return Money;
    }
    
    public void setMoney(double val){
        
        this.Money = val;
    }
     
 protected int Quantity; 
  
    protected int getQuantity(){
    
        return Quantity; 
    }
    protected void setQuantity(int val){
    
        this.Quantity = val;
    }
    
    NumberFormat formatter = NumberFormat.getCurrencyInstance();  //Helps us to get a currency form infront of the amount of the item on the print page
     
   //---------------------------------------------------------------------------------------------------- 
   //CONSTRUCTOR
   //---------------------------------------------------------------------------------------------------- 
     
    
    // Full Constructor of the Vending Machine with alot of properities inside it 

    public Soda_Vending_Machine(double Money, Queue<Soda> myPepsi, Queue<Soda> myPepsiZeroSugar, Queue<Soda> myCocaCola, Queue<Soda> myDietCoke, Queue<Soda> myFantaOrange, Queue<Soda> myFantaPineapple  ) throws CloneNotSupportedException{
       
            Pepsi= myPepsi;
            PepsiZeroSugar = myPepsiZeroSugar;
            CocaCola = myCocaCola;
            DietCoke = myDietCoke;
            FantaOrange = myFantaOrange;
            FantaPineapple = myFantaPineapple;
     
            
        Soda Pep = new Soda("Pepsi", "Original", 330, 3.95);    // Creating a Pepsi instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                Pepsi.add(Pep.clone());
                
            }
    
        Soda PepZeroSugar = new Soda("PepsiZeroSugar", "NoSugar", 500, 4.49);    // Creating a Pepsi with zero sugar instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                PepsiZeroSugar.add(PepZeroSugar.clone());
                
            }
            
        Soda Coke = new Soda("CocaCola", "Original", 250, 6.99);    // Creating a Coke instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                CocaCola.add(Coke.clone());
                
            }
            
        Soda DCoke = new Soda("DietCoke", "NoSugar", 330, 5.78);    // Creating a Diet Coke instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                DietCoke.add(DCoke.clone());
                
            }
    
        Soda FOrange = new Soda("FantaOrange", "Original", 250, 5.12);    // Creating a Fanta Orange instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                FantaOrange.add(FOrange.clone());
                
            }
            
        Soda FPineapple = new Soda("FantaPineapple", "PineappleFalvour", 500, 6.19);    // Creating a Fanta Pineapple instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                FantaPineapple.add(FPineapple.clone());
                
            }
            
            setMoney(Money); //Money in the machine
    }
    
    
   //---------------------------------------------------------------------------------------------------- 
   //METHODS
   //---------------------------------------------------------------------------------------------------- 
    
    @Override
    public String GetMachineInfo() {     
        
        DisplayContents();
     
      return null;
    }

    
    
    @Override
    public String DisplayContents() {
        
        System.out.println("");
        System.out.println("+-------------------------------------------------------------------------+");
        System.out.println("|    You Chose a Soda Machine. Here Are Your Options:                     |");
        System.out.println("+-------------------------------------------------------------------------+");
        if(!Pepsi.isEmpty()){
            System.out.println("|    A: " + " (330ml) " + " Original " + Pepsi.peek().getName() + "--------("+  Pepsi.size() + ")-------------------" + "=> " + Pepsi.peek().getPrice() + "    |");
        }
 
        if(!PepsiZeroSugar.isEmpty()){
            System.out.println("|    B: " + " (500ml) " + " " + PepsiZeroSugar.peek().getName() + "--------("+  PepsiZeroSugar.size() + ")" + "(No Sugar)---------" + "=> " + PepsiZeroSugar.peek().getPrice() + "    |");
        }
        
        if(!CocaCola.isEmpty()){
            System.out.println("|    C: " + " (250ml) " + " Original " + CocaCola.peek().getName() + "-----("+  CocaCola.size() + ")-------------------" + "=> " + CocaCola.peek().getPrice() + "    |");
        }
 
        if(!DietCoke.isEmpty()){
            System.out.println("|    D: " + " (330ml) " + " " + DietCoke.peek().getName() + "--------------("+  DietCoke.size() + ")" + "(No Sugar)---------" + "=> " + DietCoke.peek().getPrice() + "    |");
            
        }
 
        if(!FantaOrange.isEmpty()){
            System.out.println("|    E: " + " (250ml) " + " Original " + FantaOrange.peek().getName() + "--("+  FantaOrange.size() + ")-------------------" + "=> " + FantaOrange.peek().getPrice() + "    |");
        }
        
        if(!FantaPineapple.isEmpty()){
            System.out.println("|    F: " + " (500ml) " + " " + FantaPineapple.peek().getName() + "--------("+  FantaPineapple.size() + ")" + "(Pineapple Flavour)" + "=> " + FantaPineapple.peek().getPrice() + "    |");
            System.out.println("|                                                                         |");
        }
        
      return null;
    }
 

    public Soda VendItem(String slotCode) {          //.....Below there will be a bunch of if statements and also for loops which will help us to Vend the items(Soda)
        
        //Pepsi
        if (slotCode.equals("A") && Pepsi.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + Pepsi.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                Pepsi.poll();
            }
        }
        
        else if(Pepsi.equals("A") && Quantity > Pepsi.size()){
        
            System.out.println("The Vending Machine has only " + Pepsi.size() + "Pepsi. Please Make an Order below the amount left " + Pepsi.size()+ ".");
        }
        
        //PepsiZeroSugar
        if (slotCode.equals("B") && PepsiZeroSugar.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + PepsiZeroSugar.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                PepsiZeroSugar.poll();
            }
        }
        else if(PepsiZeroSugar.equals("B") && Quantity > PepsiZeroSugar.size()){
        
            System.out.println("The Vending Machine has only " + PepsiZeroSugar.size() + "Pepsi with No Sugar. Please Make an Order below the amount left " + PepsiZeroSugar.size()+ ".");
        }
        
        //CocaCola
        if (slotCode.equals("C") && CocaCola.size()>0){
            
             System.out.println("\n");
             System.out.println("Here is your " + CocaCola.peek().getName());
             System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                CocaCola.poll();
            }
        }
        else if(CocaCola.equals("C") && Quantity > CocaCola.size()){
        
            System.out.println("The Vending Machine has only " + CocaCola.size() + "Coca-Cola. Please Make an Order below the amount left " + CocaCola.size()+ ".");
        }

        //DietCoke
        if (slotCode.equals("A") && DietCoke.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + DietCoke.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                DietCoke.poll();
            }
        }
        
        else if(DietCoke.equals("A") && Quantity > DietCoke.size()){
        
            System.out.println("The Vending Machine has only " + DietCoke.size() + "Diet-Coke. Please Make an Order below the amount left " + DietCoke.size()+ ".");
        }
        
        //FantaOrange
        if (slotCode.equals("B") && FantaOrange.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + FantaOrange.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                FantaOrange.poll();
            }
        }
        else if(FantaOrange.equals("B") && Quantity > FantaOrange.size()){
        
            System.out.println("The Vending Machine has only " + FantaOrange.size() + "Fanta Organge. Please Make an Order below the amount left " + FantaOrange.size()+ ".");
        }
        
        //FantaPineapple
        if (slotCode.equals("C") && FantaPineapple.size()>0){
            
             System.out.println("\n");
             System.out.println("Here is your " + FantaPineapple.peek().getName());
             System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                FantaPineapple.poll();
            }
        }
        else if(FantaPineapple.equals("C") && Quantity > FantaPineapple.size()){
        
            System.out.println("The Vending Machine has only " + FantaPineapple.size() + "Fanta Pineapple. Please Make an Order below the amount left " + FantaPineapple.size()+ ".");
        }
        
        
      return null;         
    }

    
    
    
private static void VendingSoda(double Price, int Quantity, Soda_Vending_Machine SodaMachine, NumberFormat formatter, String slotCode) {
    
        // Below the scanner will ask for the How many Sodas does the user wants interms of Number
        
     Scanner input = new Scanner(System.in);
        
        System.out.println("HOW MUCH DO YOU NEED IN NUMBERS: ");
        String sth = input.nextLine().trim();
        
        int neededQuantity = TryParseInt(sth);
    
    while(neededQuantity == 0)
        {
            // This promot will appear if the user didn't insert the write type of answer for the question HOW MUCH YOU NEED: 
            System.out.println("ERROR!");
            System.out.println("INVALID INPUT. Please try again.");
            System.out.println("");
            System.out.println("INSERT AN ACTUAL NUMBER: "); 
            
            sth = input.nextLine().trim();
                               
            neededQuantity = TryParseInt(sth);    //.....This is used to store and parse.....I got help on this from Elias
        }
    String ss = "";
        
    while (neededQuantity > Quantity || Quantity < 0 || neededQuantity<0 ) 
            {
              // This promot will appear if the user inserts alot of quantity more than their is inside the vending machine for the question HOW MUCH YOU NEED:
                System.out.println("TOO MUCH PRODUCT ASKED. PRODUCTS OUT OF STOCK " + "\n"+" THE MACHINE HAS ONLY "+ Quantity +" INSIDE IT. ");
                System.out.println("Try again.");
                System.out.println("PLEASE INSERT THE AMOUNT YOU WANT TO PURCHASE: "); 
                ss = input.nextLine().toUpperCase().trim();
                
        if(ss.equals("Q")){
            break;
            }
                neededQuantity = (int)TryParseInt(ss);               
        }
    /*
    * I got help from Elias around here how to do the total amount or the total cost 
    */
         if (!ss.equals("Q")){
        
            SodaMachine.setQuantity(neededQuantity);      // ....used to set the wanted quantity

            Double Total_Cost = neededQuantity * Price;   //.....used to display the total cost
            System.out.println("\n"+" TOTAL COST "+ formatter.format(Total_Cost));
            System.out.println("\n"+"INSERT PAYMENT FOR THE ITEM: ");
            String aaa= input.nextLine().trim();
            Double PaymentAmount = TryParseDouble(aaa);
            SodaMachine.TakeMoney(PaymentAmount);
        
        while(PaymentAmount < Total_Cost){
            
            System.out.println("\n"+"PAYMENT INSUFFICIENT! Please insert at least an additional  "+ formatter.format(Total_Cost-PaymentAmount)+" OR CLICK 'Q' TO QUIT.");
            String Pay = input.nextLine().trim();
            
            if(Pay.toUpperCase().equals("Q")){ 
                
                SodaMachine.ReturnMoney(PaymentAmount);System.exit(0);
            }
            else{
                
                Double PayMore = TryParseDouble(Pay);
                PaymentAmount += PayMore;
                SodaMachine.addMoney(PayMore);
            }
        }
            SodaMachine.VendItem(slotCode);
            double change = PaymentAmount - Total_Cost;
            if(change>0){
                SodaMachine.GiveChange(change);
       
//Final Note for the user

        System.out.println("++================================================================++");
        System.out.println("||//////////////////THANKS FOR THE PURCHASE!!!////////////////////||");     
        System.out.println("||////////////////////HAVE A GOOD DAY:)///////////////////////////||");
        System.out.println("++================================================================++");
        System.out.println("  THE MACHINE HAS "+formatter.format(SodaMachine.getMoney())+" STORED.  ");
        System.out.println("++================================================================++");
                              
       }
     }
   }

    
public void VendOrder(String slotCode, double Price, int Quantity, Soda_Vending_Machine VendSoda, NumberFormat formatter){
        
        switch (slotCode){
            case "A":
                if (VendSoda.Pepsi.isEmpty()){
                    System.out.println("The Pepsi you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendSoda.Pepsi.peek().getPrice();
                        Quantity = VendSoda.Pepsi.size();
                        VendingSoda(Price, Quantity, VendSoda, formatter, slotCode);
                    }
                    break;
            case "B":
                if (VendSoda.PepsiZeroSugar.isEmpty()){
                    System.out.println("The Pepsi with Zero Sugar you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendSoda.PepsiZeroSugar.peek().getPrice();
                        Quantity = VendSoda.PepsiZeroSugar.size();
                        VendingSoda(Price, Quantity, VendSoda, formatter, slotCode);
                    }
                    break;
            case "C":
                if (VendSoda.CocaCola.isEmpty()){
                    System.out.println("The Coca-Cola you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendSoda.CocaCola.peek().getPrice();
                        Quantity = VendSoda.CocaCola.size();
                        VendingSoda(Price, Quantity, VendSoda, formatter, slotCode);
        
                    }
                    break;
            case "D":
                if (VendSoda.DietCoke.isEmpty()){
                    System.out.println("The Diet-Coke you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendSoda.DietCoke.peek().getPrice();
                        Quantity = VendSoda.DietCoke.size();
                        VendingSoda(Price, Quantity, VendSoda, formatter, slotCode);
                    }
                    break;
            case "E":
                if (VendSoda.FantaOrange.isEmpty()){
                    System.out.println("The Fanta Orange you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendSoda.FantaOrange.peek().getPrice();
                        Quantity = VendSoda.FantaOrange.size();
                        VendingSoda(Price, Quantity, VendSoda, formatter, slotCode);
                    }
                    break;
            case "F":
                if (VendSoda.FantaPineapple.isEmpty()){
                    System.out.println("The Fanta Pineapple you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendSoda.FantaPineapple.peek().getPrice();
                        Quantity = VendSoda.FantaPineapple.size();
                        VendingSoda(Price, Quantity, VendSoda, formatter, slotCode);
                    }
                    break;
            case "Q": 
                System.out.println("");
                    break;
                // Unless and Otherwise, Go back to the Main Menu  
                default:
                    System.out.println("THE CHOICE YOU MADE IS NOT VALID.");
                    break;
        }             
    }
   
        @Override
    public void TakeMoney(double amount) {          // .....This is an inside process the moment the payment is done, the payment that have been done will go and added to the total store amount(200.00).
    
        AddMoney(amount);
        System.out.println("\n");
        System.out.println("THANK YOU FOR THE PAYMENT YOU MADE");
        System.out.println("----------------------------------");
     }

    @Override
    public void ReturnMoney(double amount) {
        
        AddMoney(-amount);
        System.out.println("Here Is Your Money" + amount);
    }
       
    public void GiveChange(double amount){         //....In this method we calculate the change for the user, if the user pay more money.
        
        AddMoney(-amount);     
        System.out.println("\n"+"Here is your change: "+formatter.format(amount) +" ." );       
    }    
        
    public String ItemCounter(Queue <Soda> item){       //....I got a help on this Part From a Tutor and I understand that it helps to track the amount of the Candy
        
        if(item.size()<=0){
            System.out.println("WE ARE OUT OF THE ITEM FOR NOW.");
        }
        else{ 
            System.out.println(item.peek().getName() + " " + item.size() + " - " + item.peek().getName());
        }
        
      return null;
    }

    public void AddMoney(double d) {
        this.Money += d;
        
         }

    void addMoney(double d) {
        this.Money +=d;
    }
}
