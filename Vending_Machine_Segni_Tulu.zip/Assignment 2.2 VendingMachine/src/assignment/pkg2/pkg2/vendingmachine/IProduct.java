/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2.pkg2.vendingmachine;

/**
 *
 * @author stulujr.local
 */
public interface IProduct {
 
    // It is will display the name of the given product
    String DisplayName();
    
    // It will display the price of the given product
    double DisplayPrice();
    
}
