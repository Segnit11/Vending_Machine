/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.pkg2.pkg2.vendingmachine;

/**
 *
 * @author stulujr.local
 */
public class Candy implements Cloneable, IProduct {
 
   //---------------------------------------------------------------------------------------------------- 
   //PROPERTIES
   //---------------------------------------------------------------------------------------------------- 
    
    private String Name; 
        
        public String getName(){
        
            return this.Name;
        }
    
        public void setName(String val){
            
             this.Name = val;    
        }
        
           
    private double Price;            
        
        public double getPrice(){
            
            return this.Price;
        }
    
        public void setPrice(double val){
        
            this.Price = val;
        }
    
    public String fullinformation;
            
        public String getfullinformation(){
            
            return Name +" "+ Price;
        }
    
        public void setfullinformation(String val){
        
            this.fullinformation = val;
        }
        
        
   //---------------------------------------------------------------------------------------------------- 
   //CONSTRUCTOR
   //---------------------------------------------------------------------------------------------------- 
     
        
    public Candy(){}       // This is the default constructor(with no parameters)
    
    public Candy(String aName,double aPrice){           // This is the full constructor which includes all properties included as parameters
    
        Name = aName;
        Price = aPrice;        
      }
 
    @Override
    public Candy clone() throws CloneNotSupportedException {         //Clone
        return (Candy) super.clone();
    }


    private String GetProductName() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private double GetProductPrice() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String DisplayName() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public double DisplayPrice() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}