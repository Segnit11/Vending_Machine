/*
 * This is a vending machine thats vends every vending machinees together 
 */
package assignment.pkg2.pkg2.vendingmachine;

import static assignment.pkg2.pkg2.vendingmachine.MAIN_VENDING_MACHINE.TryParseDouble;
import static assignment.pkg2.pkg2.vendingmachine.MAIN_VENDING_MACHINE.TryParseInt;
import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

/**
 *
 * @author stulujr.local
 */
public class All_Vending_Machine implements IVendingMachine <IProduct>{


   //---------------------------------------------------------------------------------------------------- 
   //PROPERTIES
   //---------------------------------------------------------------------------------------------------- 
    
protected Queue<Candy> SlotA = new LinkedList();

      public Queue<Candy> getSlotA(){

        return this.SlotA;
    }

    public void setSlotA(Queue<Candy> val){

         this.SlotA = val;    
    }
        
protected Queue<Candy> SlotB = new LinkedList();
   
    
    public Queue<Candy> getSlotB(){

        return this.SlotB;
    }

    public void setSlotB(Queue<Candy> val){

         this.SlotB = val;    
    }
        
protected Queue<Candy> SlotC = new LinkedList();
    
  
    public Queue<Candy> getSlotC(){

        return this.SlotC;
    }

    public void setSlotC(Queue<Candy> val){

        this.SlotC = val;    
    }

        
    
  protected Queue<Soda> Pepsi = new LinkedList();

    public Queue<Soda> getPepsi(){

        return this.Pepsi;
    }

    public void setPepsi(Queue<Soda> val){

         this.Pepsi = val;    
    }
        
    
protected Queue<Soda> PepsiZeroSugar = new LinkedList();
   
    
    public Queue<Soda> getPepsiZeroSugar(){

        return this.PepsiZeroSugar;
    }

    public void setPepsiZeroSugar(Queue<Soda> val){

         this.Pepsi = val;  
    
    }
    
protected Queue<Soda> CocaCola = new LinkedList();
    
  
    public Queue<Soda> getCocaCola(){

        return this.CocaCola;
    }

    public void setCocaCola(Queue<Soda> val){

         this.CocaCola = val;   
    }
    
protected Queue<Soda> DietCoke = new LinkedList();
    
  
    public Queue<Soda> getDietCoke(){

        return this.DietCoke;
    }

    public void setDietCoke(Queue<Soda> val){

         this.DietCoke = val;   
    } 
 
protected Queue<Soda> FantaOrange = new LinkedList();
    
  
    public Queue<Soda> getFantaOrange(){

        return this.FantaOrange;
    }

    public void setFantaOrange(Queue<Soda> val){

         this.FantaOrange = val;   
    } 


protected Queue<Soda> FantaPineapple = new LinkedList();
    
  
    public Queue<Soda> getFantaPineapple(){

        return this.FantaPineapple;
    }

    public void setFantaPineapple(Queue<Soda> val){

         this.FantaPineapple = val;   
    }
    
    
    
   
  protected Queue<StarWarsCharacter> Asajj = new LinkedList();

    public Queue<StarWarsCharacter> getAsajj(){

        return this.Asajj;
    }

    public void setAsajj(Queue<StarWarsCharacter> val){

         this.Asajj = val;    
    }
        
    
protected Queue<StarWarsCharacter> Bariss = new LinkedList();

    public Queue<StarWarsCharacter> getBariss(){

        return this.Bariss;
    }

    public void setBariss(Queue<StarWarsCharacter> val){

         this.Bariss = val;    
    }
  
protected Queue<StarWarsCharacter> Darth = new LinkedList();

    public Queue<StarWarsCharacter> getDarth(){

        return this.Darth;
    }

    public void setDarth(Queue<StarWarsCharacter> val){

         this.Darth = val;    
    }
    
protected Queue<StarWarsCharacter> Emperor = new LinkedList();

    public Queue<StarWarsCharacter> getEmperor(){

        return this.Emperor;
    }

    public void setEmperor(Queue<StarWarsCharacter> val){

         this.Emperor = val;    
    }

protected Queue<StarWarsCharacter> Kylo = new LinkedList();

    public Queue<StarWarsCharacter> getKylo(){

        return this.Kylo;
    }

    public void setKylo(Queue<StarWarsCharacter> val){

         this.Kylo = val;    
    }   
    
    
protected Queue<StarWarsCharacter> Luke = new LinkedList();

    public Queue<StarWarsCharacter> getLuke(){

        return this.Luke;
    }

    public void setLuke(Queue<StarWarsCharacter> val){

         this.Luke = val;    
    }     
    
protected Queue<StarWarsCharacter> Obi = new LinkedList();

    public Queue<StarWarsCharacter> getObi(){

        return this.Obi;
    }

    public void setObi(Queue<StarWarsCharacter> val){

         this.Obi = val;    
    }  
    
    
protected Queue<StarWarsCharacter> Princess = new LinkedList();

    public Queue<StarWarsCharacter> getPrincess(){

        return this.Princess;
    }

    public void setPrincess(Queue<StarWarsCharacter> val){

         this.Princess = val;    
    }  
    
protected Queue<StarWarsCharacter> Rey = new LinkedList();

    public Queue<StarWarsCharacter> getRey(){

        return this.Rey;
    }

    public void setRey(Queue<StarWarsCharacter> val){

         this.Rey = val;    
    }  
    
protected Queue<StarWarsCharacter> Storm = new LinkedList();

    public Queue<StarWarsCharacter> getStorm(){

        return this.Storm;
    }

    public void setStorm(Queue<StarWarsCharacter> val){

         this.Storm = val;    
    }      
    
    
protected Queue<StarWarsCharacter> Yoda = new LinkedList();

    public Queue<StarWarsCharacter> getYoda(){

        return this.Yoda;
    }

    public void setYoda(Queue<StarWarsCharacter> val){

         this.Yoda = val;    
    }
    
 
   Double Money;
    
 
    protected Double getMoney(){
           
        return Money;
    }
    
    public void setMoney(double val){
        
        this.Money = val;
    }
     
 protected int Quantity; 
  
    protected int getQuantity(){
    
        return Quantity; 
    }
    protected void setQuantity(int val){
    
        this.Quantity = val;
    }
    
    NumberFormat formatter = NumberFormat.getCurrencyInstance();  //Helps us to get a currency form infront of the amount of the item on the print page
  
    
   //---------------------------------------------------------------------------------------------------- 
   //CONSTRUCTOR
   //---------------------------------------------------------------------------------------------------- 
    
       // Full Constructor of the Vending Machine with alot of properities inside it 

    public All_Vending_Machine(double Money, Queue<Candy> mySlotA, Queue<Candy> mySlotB, Queue<Candy> mySlotC, Queue<Soda> myPepsi, Queue<Soda> myPepsiZeroSugar, Queue<Soda> myCocaCola, Queue<Soda> myDietCoke, Queue<Soda> myFantaOrange, Queue<Soda> myFantaPineapple, Queue<StarWarsCharacter> myAsajj, Queue<StarWarsCharacter> myBariss, Queue<StarWarsCharacter> myDarth, Queue<StarWarsCharacter> myEmperor, Queue<StarWarsCharacter> myKylo, Queue<StarWarsCharacter> myLuke, Queue<StarWarsCharacter> myObi, Queue<StarWarsCharacter> myPrincess, Queue<StarWarsCharacter> myRey, Queue<StarWarsCharacter> myStorm, Queue<StarWarsCharacter> myYoda ) throws CloneNotSupportedException{
       
            SlotA = mySlotA;
            SlotB = mySlotB;
            SlotC = mySlotC;
            
            Pepsi= myPepsi;
            PepsiZeroSugar = myPepsiZeroSugar;
            CocaCola = myCocaCola;
            DietCoke = myDietCoke;
            FantaOrange = myFantaOrange;
            FantaPineapple = myFantaPineapple;
            
            Asajj= myAsajj;
            Bariss=myBariss;
            Darth=myDarth;
            Emperor=myEmperor;
            Kylo=myKylo;
            Luke=myLuke;
            Obi=myObi;
            Princess=myPrincess;
            Rey=myRey;
            Storm=myStorm;
            Yoda=myYoda;
     
            
        Candy sk1 = new Candy("Skittles", 4.20);    // Creating a Skittles instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                SlotA.add(sk1.clone());
                
            }
    
        Candy sn1 = new Candy("Snickers", 1.42);    // Creating a Snickers instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
                
                SlotB.add(sn1.clone());
                
            }
            
        Candy mm1 = new Candy("MandMs",42.42);      // Creating a MandMs instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
                
                SlotC.add(mm1.clone());
                
            }
    
        Soda Pep = new Soda("Pepsi", "Original", 330, 3.95);    // Creating a Pepsi instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                Pepsi.add(Pep.clone());
                
            }
    
        Soda PepZeroSugar = new Soda("PepsiZeroSugar", "NoSugar", 500, 4.49);    // Creating a Pepsi with zero sugar instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                PepsiZeroSugar.add(PepZeroSugar.clone());
                
            }
            
        Soda Coke = new Soda("CocaCola", "Original", 250, 6.99);    // Creating a Coke instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                CocaCola.add(Coke.clone());
                
            }
            
        Soda DCoke = new Soda("DietCoke", "NoSugar", 330, 5.78);    // Creating a Diet Coke instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                DietCoke.add(DCoke.clone());
                
            }
    
        Soda FOrange = new Soda("FantaOrange", "Original", 250, 5.12);    // Creating a Fanta Orange instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                FantaOrange.add(FOrange.clone());
                
            }
            
        Soda FPineapple = new Soda("FantaPineapple", "PineappleFalvour", 500, 6.19);    // Creating a Fanta Pineapple instance vaiable and its Price
        
            for(int i=1; i<=10; i++){
               
                FantaPineapple.add(FPineapple.clone());
                
            }
            
            
            
            
        StarWarsCharacter Ch1 = new StarWarsCharacter("Asajj","Ventess", new TheForce(88,"Dark"),4.56);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Asajj.add(Ch1.clone());    
            }
    
        StarWarsCharacter Ch2 = new StarWarsCharacter("Bariss","Offee", new TheForce(85,"Light"),5.67);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Bariss.add(Ch2.clone());    
            }
            
        StarWarsCharacter Ch3 = new StarWarsCharacter("Darth","Vader", new TheForce(100,"Dark"),7.96);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Darth.add(Ch3.clone());    
            }
            
        StarWarsCharacter Ch4 = new StarWarsCharacter("Emperor","Palpatine", new TheForce(97,"Dark"), 5.76);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){ 
                Emperor.add(Ch4.clone());    
            }
            
        StarWarsCharacter Ch5 = new StarWarsCharacter("Kylo","Ren", new TheForce(95,"Dark"), 9.34);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Kylo.add(Ch5.clone());    
            }
            
        StarWarsCharacter Ch6 = new StarWarsCharacter("Luke","Skywalker", new TheForce(97,"Light"),3.88);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){  
                Luke.add(Ch6.clone());    
            }

        StarWarsCharacter Ch7 = new StarWarsCharacter("Obi Wan","Kenobi", new TheForce(85,"Light"),4.31);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Obi.add(Ch7.clone());   
            }

        StarWarsCharacter Ch8 = new StarWarsCharacter("Princess","Leia", new TheForce(75,"Light"),6.23);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Princess.add(Ch8.clone());    
            }

        StarWarsCharacter Ch9 = new StarWarsCharacter("Rey","", new TheForce(96,"Light"),5.34);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Rey.add(Ch9.clone());    
            }

        StarWarsCharacter Ch10 = new StarWarsCharacter("Storm","Trooper",new TheForce(1,"Dark"),1.87);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Storm.add(Ch10.clone());   
            }

        StarWarsCharacter Ch11 = new StarWarsCharacter("Yoda","",new TheForce(99,"Light"), 2.65);    // Creating a Skittles instance vaiable and its Price
            for(int i=1; i<=10; i++){   
                Yoda.add(Ch11.clone());    
            }
            
            setMoney(Money); //Money in the machine
    }
    
   //---------------------------------------------------------------------------------------------------- 
   //METHODS
   //---------------------------------------------------------------------------------------------------- 
    
@Override
    public String GetMachineInfo() {     
        
        DisplayContents();
     
      return null;
    }

    
    
@Override
    public String DisplayContents() {
        
        System.out.println("");
        System.out.println("+-------------------------------------------------------------------------+");
        System.out.println("|    You Chose a Miscellaneous Machine. Here Are Your Options:            |");
        System.out.println("+-------------------------------------------------------------------------+");
        
        if(!SlotA.isEmpty()){
            System.out.println("|    A: " + SlotA.peek().getName() + "  ("+  SlotA.size() + ") " + "= " + SlotA.peek().getPrice() + "                                              |");
            
        }
 
        if(!SlotB.isEmpty()){
            System.out.println("|    B: " + SlotB.peek().getName() + "  ("+  SlotB.size() + ") " + "= " + SlotB.peek().getPrice() + "                                             |");
        }
        
        if(!SlotC.isEmpty()){
            System.out.println("|    C: " + SlotC.peek().getName() + "  ("+  SlotC.size() + ") " + "= " + SlotC.peek().getPrice() + "                                              |");
        }
 
        if(!Pepsi.isEmpty()){
            System.out.println("|    D: " + " (330ml) " + " Original " + Pepsi.peek().getName() + "--------("+  Pepsi.size() + ")-------------------" + "=> " + Pepsi.peek().getPrice() + "    |");
        }
 
        if(!PepsiZeroSugar.isEmpty()){
            System.out.println("|    E: " + " (500ml) " + " " + PepsiZeroSugar.peek().getName() + "--------("+  PepsiZeroSugar.size() + ")" + "(No Sugar)---------" + "=> " + PepsiZeroSugar.peek().getPrice() + "    |");
        }
        
        if(!CocaCola.isEmpty()){
            System.out.println("|    F: " + " (250ml) " + " Original " + CocaCola.peek().getName() + "-----("+  CocaCola.size() + ")-------------------" + "=> " + CocaCola.peek().getPrice() + "    |");
        }
 
        if(!DietCoke.isEmpty()){
            System.out.println("|    G: " + " (330ml) " + " " + DietCoke.peek().getName() + "--------------("+  DietCoke.size() + ")" + "(No Sugar)---------" + "=> " + DietCoke.peek().getPrice() + "    |");
            
        }
 
        if(!FantaOrange.isEmpty()){
            System.out.println("|    H: " + " (250ml) " + " Original " + FantaOrange.peek().getName() + "--("+  FantaOrange.size() + ")-------------------" + "=> " + FantaOrange.peek().getPrice() + "    |");
        }
        
        if(!FantaPineapple.isEmpty()){
            System.out.println("|    I: " + " (500ml) " + " " + FantaPineapple.peek().getName() + "--------("+  FantaPineapple.size() + ")" + "(Pineapple Flavour)" + "=> " + FantaPineapple.peek().getPrice() + "    |");
        }
        
        
        
        if(!Asajj.isEmpty()){
            System.out.println("|    J:" + Asajj.peek().getFirstName() + " " + Asajj.peek().getLastName() + "------("+  Asajj.size() + ") " + "= " + Asajj.peek().getPrice() + "                                     |");    
        }
 
        if(!Bariss.isEmpty()){
            System.out.println("|    K:" + Bariss.peek().getFirstName() + " " + Bariss.peek().getLastName() + "-------("+  Bariss.size() + ") " + "= " + Bariss.peek().getPrice() + "                                     |");    
        }
        
        if(!Darth.isEmpty()){
            System.out.println("|    L:" + Darth.peek().getFirstName() + " " + Darth.peek().getLastName() + "--------("+  Darth.size() + ") " + "= " + Darth.peek().getPrice() + "                                     |");    
        }
        
        if(!Emperor.isEmpty()){
            System.out.println("|    M:" + Emperor.peek().getFirstName() + " " + Emperor.peek().getLastName() + "--("+  Emperor.size() + ") " + "= " + Emperor.peek().getPrice() + "                                     |");    
        }
 
        if(!Kylo.isEmpty()){
            System.out.println("|    N:" + Kylo.peek().getFirstName() + " " + Kylo.peek().getLastName() + "-----------("+  Kylo.size() + ") " + "= " + Kylo.peek().getPrice() + "                                     |");    
        }
        
        if(!Luke.isEmpty()){
            System.out.println("|    O:" + Luke.peek().getFirstName() + " " + Luke.peek().getLastName() + "-----("+  Luke.size() + ") " + "= " + Luke.peek().getPrice() + "                                     |");   
        }
        
        if(!Obi.isEmpty()){
            System.out.println("|    P:" + Obi.peek().getFirstName() + " " + Obi.peek().getLastName() + "-----("+  Obi.size() + ") " + "= " + Obi.peek().getPrice() + "                                     |");    
        }
        
        if(!Princess.isEmpty()){
            System.out.println("|    R:" + Princess.peek().getFirstName() + " " + Princess.peek().getLastName() + "------("+  Princess.size() + ") " + "= " + Princess.peek().getPrice() + "                                     |");    
        }
        
        if(!Rey.isEmpty()){
            System.out.println("|    S:" + Rey.peek().getFirstName() + " " + Rey.peek().getLastName() + "---------------("+  Rey.size() + ") " + "= " + Rey.peek().getPrice() + "                                     |");    
        }
        
        if(!Storm.isEmpty()){
            System.out.println("|    T:" + Storm.peek().getFirstName() + " " + Storm.peek().getLastName() + "------("+  Storm.size() + ") " + "= " + Storm.peek().getPrice() + "                                     |");   
        }
        
        if(!Yoda.isEmpty()){
            System.out.println("|    U:" + Yoda.peek().getFirstName() + " " + Yoda.peek().getLastName() + "--------------("+  Yoda.size() + ") " + "= " + Yoda.peek().getPrice() + "                                     |");    
            System.out.println("|                                                                         |");
        }

      return null;
    }


    
    public Candy VendItem(String slotCode) {          //.....Below there will be a bunch of if statements and also for loops which will help us to Vend the items(Candy)
        
        //SlotA
        if (slotCode.equals("A") && SlotA.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + SlotA.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                SlotA.poll();
            }
        }
        
        else if(SlotA.equals("A") && Quantity > SlotA.size()){
        
            System.out.println("The Vending Machine has only " + SlotA.size() + "Skittles. Please Make an Order below the amount left " + SlotA.size()+ ".");
        }
        
        //SlotB
        if (slotCode.equals("B") && SlotB.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + SlotB.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                SlotB.poll();
            }
        }
        else if(SlotB.equals("B") && Quantity > SlotB.size()){
        
            System.out.println("The Vending Machine has only " + SlotB.size() + "Snickers. Please Make an Order below the amount left " + SlotB.size()+ ".");
        }
        
        //SlotC
        if (slotCode.equals("C") && SlotC.size()>0){
            
             System.out.println("\n");
             System.out.println("Here is your " + SlotC.peek().getName());
             System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                SlotC.poll();
            }
        }
        else if(SlotC.equals("C") && Quantity > SlotC.size()){
        
            System.out.println("The Vending Machine has only " + SlotC.size() + "Snickers. Please Make an Order below the amount left " + SlotC.size()+ ".");
        }
        
        //Pepsi
        if (slotCode.equals("D") && Pepsi.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + Pepsi.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                Pepsi.poll();
            }
        }
        
        else if(Pepsi.equals("D") && Quantity > Pepsi.size()){
        
            System.out.println("The Vending Machine has only " + Pepsi.size() + "Pepsi. Please Make an Order below the amount left " + Pepsi.size()+ ".");
        }
        
        //PepsiZeroSugar
        if (slotCode.equals("E") && PepsiZeroSugar.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + PepsiZeroSugar.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                PepsiZeroSugar.poll();
            }
        }
        else if(PepsiZeroSugar.equals("E") && Quantity > PepsiZeroSugar.size()){
        
            System.out.println("The Vending Machine has only " + PepsiZeroSugar.size() + "Pepsi with No Sugar. Please Make an Order below the amount left " + PepsiZeroSugar.size()+ ".");
        }
        
        //CocaCola
        if (slotCode.equals("F") && CocaCola.size()>0){
            
             System.out.println("\n");
             System.out.println("Here is your " + CocaCola.peek().getName());
             System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                CocaCola.poll();
            }
        }
        else if(CocaCola.equals("F") && Quantity > CocaCola.size()){
        
            System.out.println("The Vending Machine has only " + CocaCola.size() + "Coca-Cola. Please Make an Order below the amount left " + CocaCola.size()+ ".");
        }

        //DietCoke
        if (slotCode.equals("G") && DietCoke.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + DietCoke.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                DietCoke.poll();
            }
        }
        
        else if(DietCoke.equals("G") && Quantity > DietCoke.size()){
        
            System.out.println("The Vending Machine has only " + DietCoke.size() + "Diet-Coke. Please Make an Order below the amount left " + DietCoke.size()+ ".");
        }
        
        //FantaOrange
        if (slotCode.equals("H") && FantaOrange.size()>0){
            
            System.out.println("\n");
            System.out.println("Here is your " + FantaOrange.peek().getName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                FantaOrange.poll();
            }
        }
        else if(FantaOrange.equals("H") && Quantity > FantaOrange.size()){
        
            System.out.println("The Vending Machine has only " + FantaOrange.size() + "Fanta Organge. Please Make an Order below the amount left " + FantaOrange.size()+ ".");
        }
        
        //FantaPineapple
        if (slotCode.equals("I") && FantaPineapple.size()>0){
            
             System.out.println("\n");
             System.out.println("Here is your " + FantaPineapple.peek().getName());
             System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){
                
                FantaPineapple.poll();
            }
        }
        else if(FantaPineapple.equals("I") && Quantity > FantaPineapple.size()){
        
            System.out.println("The Vending Machine has only " + FantaPineapple.size() + "Fanta Pineapple. Please Make an Order below the amount left " + FantaPineapple.size()+ ".");
        }
        
        
        
        //Asajj
        if (slotCode.equals("J") && Asajj.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Asajj.peek().getFirstName() + Asajj.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){   
                Asajj.poll();
            }
        }
        else if(Asajj.equals("J") && Quantity > Asajj.size()){
            System.out.println("The Vending Machine has only " + Asajj.size() + "Asajj. Please Make an Order below the amount left " + Asajj.size()+ ".");
        }
        
        //Bariss
        if (slotCode.equals("K") && Bariss.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Bariss.peek().getFirstName() + Bariss.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){   
                Bariss.poll();
            }
        }
        else if(Bariss.equals("K") && Quantity > Bariss.size()){
            System.out.println("The Vending Machine has only " + Bariss.size() + "Bariss. Please Make an Order below the amount left " + Darth.size()+ ".");
        }
        
        //Darth
        if (slotCode.equals("L") && Darth.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Darth.peek().getFirstName() + Darth.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){   
                Darth.poll();
            }
        }
        else if(Darth.equals("L") && Quantity > Darth.size()){
            System.out.println("The Vending Machine has only " + Darth.size() + "Darth. Please Make an Order below the amount left " + Darth.size()+ ".");
        }

        //Emperor
        if (slotCode.equals("M") && Emperor.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Emperor.peek().getFirstName() + Emperor.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){     
                Emperor.poll();
            }
        }
        else if(Emperor.equals("M") && Quantity > Emperor.size()){
            System.out.println("The Vending Machine has only " + Emperor.size() + "Emperor. Please Make an Order below the amount left " + Emperor.size()+ ".");
        }
        
        //Kylo
        if (slotCode.equals("N") && Kylo.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Kylo.peek().getFirstName() + Kylo.peek().getLastName());
            System.out.println("\n");
           
        for(int i = 1; i <= Quantity; i++){           
                Kylo.poll();
            }
        }
        else if(Kylo.equals("N") && Quantity > Kylo.size()){
            System.out.println("The Vending Machine has only " + Kylo.size() + "Kylo. Please Make an Order below the amount left " + Kylo.size()+ ".");
        }
        
        //Luke
        if (slotCode.equals("O") && Luke.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Luke.peek().getFirstName() + Luke.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){    
                Luke.poll();
            }
        }
        else if(Luke.equals("O") && Quantity > Luke.size()){
            System.out.println("The Vending Machine has only " + Luke.size() + "Luke. Please Make an Order below the amount left " + Luke.size()+ ".");
        }
         
        //Obi
        if (slotCode.equals("P") && Obi.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Obi.peek().getFirstName() + Obi.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){   
                Obi.poll();
            }
        }
        else if(Obi.equals("P") && Quantity > Obi.size()){
            System.out.println("The Vending Machine has only " + Obi.size() + "Obi. Please Make an Order below the amount left " + Obi.size()+ ".");
        }
        
        
       //Princess
        if (slotCode.equals("R") && Princess.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Princess.peek().getFirstName() + Princess.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){    
                Princess.poll();
            }
        } 
        else if(Princess.equals("R") && Quantity > Princess.size()){
            System.out.println("The Vending Machine has only " + Princess.size() + "Obi. Please Make an Order below the amount left " + Princess.size()+ ".");
        }
       
        //Rey
        if (slotCode.equals("S") && Rey.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Rey.peek().getFirstName() + Rey.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){    
                Rey.poll();
            }
        }
        else if(Rey.equals("S") && Quantity > Rey.size()){
            System.out.println("The Vending Machine has only " + Rey.size() + "Rey. Please Make an Order below the amount left " + Rey.size()+ ".");
        }
        
         //Storm
        if (slotCode.equals("T") && Storm.size()>0){
            System.out.println("\n");
            System.out.println("Here is your " + Storm.peek().getFirstName() + Storm.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){    
                Storm.poll();
            }
        }
        else if(Storm.equals("T") && Quantity > Storm.size()){     
            System.out.println("The Vending Machine has only " + Storm.size() + "Storm. Please Make an Order below the amount left " + Storm.size()+ ".");
        }
        
         //Yoda
        if (slotCode.equals("U") && Yoda.size()>0){    
            System.out.println("\n");
            System.out.println("Here is your " + Yoda.peek().getFirstName() + Yoda.peek().getLastName());
            System.out.println("\n");
        for(int i = 1; i <= Quantity; i++){     
                Yoda.poll();
            }
        }
        else if(Yoda.equals("U") && Quantity > Yoda.size()){
            System.out.println("The Vending Machine has only " + Yoda.size() + "Yoda. Please Make an Order below the amount left " + Yoda.size()+ ".");
        }

      return null;         
    }

    
    
    
    
    private static void VendingAll(double Price, int Quantity, All_Vending_Machine AllMachine, NumberFormat formatter, String slotCode) {
    
        // Below the scanner will ask for the How many Candies does the user wants interms of Number
        
     Scanner input = new Scanner(System.in);
        
        System.out.println("HOW MUCH DO YOU NEED:");
        String sth = input.nextLine().trim();
        
        int neededQuantity = TryParseInt(sth);
    
    while(neededQuantity == 0)
        {
            // This promot will appear if the user didn't insert the write type of answer for the question HOW MUCH YOU NEED: 
            System.out.println("INVALID INPUT."+"\n"+ " Please try again.");
            System.out.println("\n");
            System.out.println("INSERT AN ACTUAL NUMBER ONLY EXCEPT 0.");
            System.out.println("INSERT A VALID QUANTITY: ");
            
            sth = input.nextLine().trim();
                               
            neededQuantity = TryParseInt(sth);    //.....This is used to store and parse.....I got help on this from Elias
        }
    String ss = "";
        
    while (neededQuantity > Quantity || Quantity < 0 || neededQuantity<0 ) 
            {
              // This promot will appear if the user inserts alot of quantity more than their is inside the vending machine for the question HOW MUCH YOU NEED:
                System.out.println("TOO MUCH PRODUCT ASKED. PRODUCTS OUT OF STOCK " + "\n"+" THE MACHINE HAS ONLY "+ Quantity +" INSIDE IT. ");
                System.out.println("Try again.");
                System.out.println("\n");
                System.out.println("PLEASE INSERT THE AMOUNT YOU WANT TO PURCHASE: "); 
                ss = input.nextLine().toUpperCase().trim();
                
        if(ss.equals("Q")){
            break;
            }
                neededQuantity = (int)TryParseInt(ss);               
        }
    /*
    * I got help from Elias around here how to do the total amount or the total cost and how to insert for the 
    */
         if (!ss.equals("Q")){
        
            AllMachine.setQuantity(neededQuantity);      // ....used to set the wanted quantity

            Double Total_Cost = neededQuantity * Price;   //.....used to display the total cost
            System.out.println("\n"+" TOTAL COST "+ formatter.format(Total_Cost));
            System.out.println("\n"+"INSERT PAYMENT FOR THE ITEM: ");
            String aaa= input.nextLine().trim();
            Double PaymentAmount = TryParseDouble(aaa);
            AllMachine.TakeMoney(PaymentAmount);
        
        while(PaymentAmount < Total_Cost){
            
            System.out.println("\n"+"Insufficient funds. Please insert at least an additional  "+ formatter.format(Total_Cost-PaymentAmount)+" or click 'Q' to quit.");
            String Pay = input.nextLine().trim();
            
            if(Pay.toUpperCase().equals("Q")){ 
                
                AllMachine.ReturnMoney(PaymentAmount);System.exit(0);
            }
            else{
                
                Double PayMore = TryParseDouble(Pay);
                PaymentAmount += PayMore;
                AllMachine.addMoney(PayMore);
            }
        }
            AllMachine.VendItem(slotCode);
            double change = PaymentAmount - Total_Cost;
            if(change>0){
                AllMachine.GiveChange(change);
        //Final Note for the user
 //Final Note...
        System.out.println("++================================================================++");
        System.out.println("||////////////////////////////////////////////////////////////////||");
        System.out.println("||//////////////////THANKS FOR THE PURCHASE!!!////////////////////||");     
        System.out.println("||////////////////////HAVE A GOOD DAY:)///////////////////////////||");
        System.out.println("||////////////////////////////////////////////////////////////////||");
        System.out.println("++================================================================++");
        System.out.println("||////////////////////////////////////////////////////////////////||");
        System.out.println("  The machine has "+formatter.format(AllMachine.getMoney())+" stored.  ");
        System.out.println("||////////////////////////////////////////////////////////////////||");
        System.out.println("++================================================================++");
        
      }
    }
   }
    
public static void VendOrder(String slotCode, double Price, int Quantity, All_Vending_Machine VendAll, NumberFormat formatter) throws CloneNotSupportedException
    {
       switch (slotCode){
        case "A":
            if (VendAll.SlotA.isEmpty()){
                System.out.println("The Skittles you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendAll.SlotA.peek().getPrice();
                        Quantity = VendAll.SlotA.size();
                        VendingAll(Price, Quantity, VendAll,formatter,slotCode);
                    }
                    break;
        case "B":
            if (VendAll.SlotB.isEmpty()){
                System.out.println("The Snickers you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendAll.SlotB.peek().getPrice();
                        Quantity = VendAll.SlotB.size();
                        VendingAll(Price, Quantity, VendAll,formatter,slotCode);
                    }
                    break;
        case "C":
            if (VendAll.SlotC.isEmpty()){
                     System.out.println("The M&M's you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendAll.SlotC.peek().getPrice();
                        Quantity = VendAll.SlotC.size();
                        VendingAll(Price, Quantity, VendAll,formatter,slotCode);
                    }
                    break;
                
                
                   
    
            case "D":
                if (VendAll.Pepsi.isEmpty()){
                    System.out.println("The Pepsi you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendAll.Pepsi.peek().getPrice();
                        Quantity = VendAll.Pepsi.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
                    }
                    break;
            case "E":
                if (VendAll.PepsiZeroSugar.isEmpty()){
                    System.out.println("The Pepsi with Zero Sugar you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendAll.PepsiZeroSugar.peek().getPrice();
                        Quantity = VendAll.PepsiZeroSugar.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
                    }
                    break;
            case "F":
                if (VendAll.CocaCola.isEmpty()){
                    System.out.println("The Coca-Cola you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendAll.CocaCola.peek().getPrice();
                        Quantity = VendAll.CocaCola.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
            case "G":
                if (VendAll.DietCoke.isEmpty()){
                    System.out.println("The Diet-Coke you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendAll.DietCoke.peek().getPrice();
                        Quantity = VendAll.DietCoke.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
                    }
                    break;
            case "H":
                if (VendAll.FantaOrange.isEmpty()){
                    System.out.println("The Fanta Orange you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendAll.FantaOrange.peek().getPrice();
                        Quantity = VendAll.FantaOrange.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
                    }
                    break;
            case "I":
                if (VendAll.FantaPineapple.isEmpty()){
                    System.out.println("The Fanta Pineapple you chose is out of stock. Choose something else.");}
                    else{   
                        Price = VendAll.FantaPineapple.peek().getPrice();
                        Quantity = VendAll.FantaPineapple.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
                    }
                    break;
            
                    
                    
                    
                case "J":
                    if (VendAll.Asajj.isEmpty()){
                        System.out.println("The Character Asajj is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Asajj.peek().getPrice();
                        Quantity = VendAll.Asajj.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
                case "K":
                    if (VendAll.Bariss.isEmpty()){
                        System.out.println("The Character Bariss is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Bariss.peek().getPrice();
                        Quantity = VendAll.Bariss.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
                case "L":
                    if (VendAll.Darth.isEmpty()){
                        System.out.println("The Character Darth is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Darth.peek().getPrice();
                        Quantity = VendAll.Darth.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
                case "M":
                    if (VendAll.Emperor.isEmpty()){
                        System.out.println("The Character Emperor is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Emperor.peek().getPrice();
                        Quantity = VendAll.Emperor.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
                case "N":
                    if (VendAll.Kylo.isEmpty()){
                        System.out.println("The Character Kylo is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Kylo.peek().getPrice();
                        Quantity = VendAll.Kylo.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
                case "O":
                    if (VendAll.Luke.isEmpty()){
                        System.out.println("The Character Luke is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Luke.peek().getPrice();
                        Quantity = VendAll.Luke.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
                case "P":
                    if (VendAll.Obi.isEmpty()){
                        System.out.println("The Character Obi is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Obi.peek().getPrice();
                        Quantity = VendAll.Obi.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
                case "R":
                    if (VendAll.Princess.isEmpty()){
                        System.out.println("The Character Princess is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Princess.peek().getPrice();
                        Quantity = VendAll.Princess.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
                case "S":
                    if (VendAll.Rey.isEmpty()){
                        System.out.println("The Character Rey is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Rey.peek().getPrice();
                        Quantity = VendAll.Rey.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
                case "T":
                    if (VendAll.Storm.isEmpty()){
                        System.out.println("The Character Storm is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Storm.peek().getPrice();
                        Quantity = VendAll.Storm.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
                case "U":
                    if (VendAll.Yoda.isEmpty()){
                        System.out.println("The Character Yoda is out of stock. Choose something else.");}
                    else
                    {   
                        Price = VendAll.Bariss.peek().getPrice();
                        Quantity = VendAll.Bariss.size();
                        VendingAll(Price, Quantity, VendAll, formatter, slotCode);
        
                    }
                    break;
            case "Q": 
                     System.out.println("");
                     break;
                // Unless and Otherwise, Go back to the Main Menu  
                default:
                    System.out.println(" THE CHOICE YOU MADE IS NOT VALID.");
                    break;
       }
    }

    @Override
    public void TakeMoney(double amount) {          // .....This is an inside process the moment the payment is done, the payment that have been done will go and added to the total store amount(200.00).
    
        AddMoney(amount);
        System.out.println("\n");
        System.out.println("THANK YOU FOR THE PAYMENT YOU MADE");
        System.out.println("----------------------------------");
     }

    @Override
    public void ReturnMoney(double amount) {
        
        AddMoney(-amount);
        System.out.println("Here Is Your Money" + amount);
    }
       
    public void GiveChange(double amount){         //....In this method we calculate the change for the user, if the user pay more money.
        
        AddMoney(-amount);     
        System.out.println("\n"+"Here is your change: "+formatter.format(amount) +" ." );       
    }    
        
    public String ItemCounter(Queue <Candy> item){       //....I got a help on this Part From a Tutor and I understand that it helps to track the amount of the Candy
        
        if(item.size()<=0){
            
            System.out.println("WE ARE OUT OF THE ITEM FOR NOW.");
        }
        
        else{
            
            System.out.println(item.peek().getName() + " " + item.size() + " - " + item.peek().getName());
        }
        
      return null;
    }

    public void AddMoney(double d) {
        this.Money += d;
        
         }
    
   
    private static Double TryParseDouble(String Pay) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private static int TryParseInt(String sth) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }


    void addMoney(double d) {
        this.Money +=d;
    }
 
}

  
    
