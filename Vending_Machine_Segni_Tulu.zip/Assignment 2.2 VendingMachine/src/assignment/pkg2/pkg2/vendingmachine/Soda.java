/*
* This is a separate class for the soda to use in the vending machines. 
* Each soda item has their getters and setters and also the constructors for their names, flavours, volumes and prices. 
*/
package assignment.pkg2.pkg2.vendingmachine;

/**
 *
 * @author stulujr.local
 */

public class Soda implements Cloneable {
 
    
    private String Name; 
        
        public String getName(){
        
            return this.Name;
        }
    
        public void setName(String val){
            
             this.Name = val;    
        }
  
        
    private String Flavour; 
        
        public String getFlavour(){
        
            return this.Flavour;
        }
    
        public void setFlavour(String val){
            
             this.Name = val;    
        }        
        
        
    private double Volume; 
        
        public double getVolume(){
        
            return this.Volume;
        }
    
        public void setVolume(String val){
            
             this.Name = val;    
        }
            
            
           
    private double Price;            
        
        public double getPrice(){
            
            return this.Price;
        }
    
        public void setPrice(double val){
        
            this.Price = val;
        }
    
        
    public String fullinformation;
            
        public String getfullinformation(){
            
            return Name +" "+ Volume +" "+ Flavour +" "+ Price;
        }
    
        public void setfullinformation(String val){
        
            this.fullinformation = val;
        }
        
        
   //---------------------------------------------------------------------------------------------------- 
   //CONSTRUCTOR
   //---------------------------------------------------------------------------------------------------- 
     
        
    public Soda(){}       // This is the default constructor(with no parameters)
    
    public Soda(String aName, String aFlavour, double aVolume, double aPrice){           // This is the full constructor which includes all properties included as parameters
    
        Name = aName;
        Flavour = aFlavour;
        Volume = aVolume;
        Price = aPrice;        
      }
 
   @Override
    public Soda clone() throws CloneNotSupportedException {         //Clone
       
       return (Soda ) super.clone();
   
      }
        
}
